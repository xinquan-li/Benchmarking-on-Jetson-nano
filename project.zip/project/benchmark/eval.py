from gluoncv.data import VOCDetection
from gluoncv import data as gdata
from gluoncv.data.batchify import Tuple, Stack, Pad
from gluoncv.data.transforms.presets.ssd import SSDDefaultValTransform
from gluoncv.utils.metrics.voc_detection import VOC07MApMetric
import time
import sys
import numpy as np
import mxnet as mx
from mxnet import nd
from mxnet import gluon
from tqdm import tqdm
from gluoncv import model_zoo, data, utils
from jtop import jtop
import os
from mxnet.contrib.quantization import *
#get dataset
val_dataset = gdata.VOCDetection(splits=[(2007, 'test')])
val_metric = VOC07MApMetric(iou_thresh=0.5, class_names=val_dataset.classes)

#running on GPU context, set it to 0 to disable cuDNN autotune
os.environ["MXNET_CUDNN_AUTOTUNE_DEFAULT"] = "0"

#api from Jtop, show the situation of Jetson nano
def show_navida():
    print("Navida situation")
    with jtop() as jetson:
            # Read tegra stats
            print(jetson.stats)
            # Status disk
            print(jetson.disk)

#dataloader of valdation dataset
def get_dataloader(val_dataset, data_shape, batch_size, num_workers):
    """Get dataloader."""
    width, height = data_shape, data_shape
    batchify_fn = Tuple(Stack(), Pad(pad_val=-1))
    val_loader = gluon.data.DataLoader(
        val_dataset.transform(SSDDefaultValTransform(width, height)), batchify_fn=batchify_fn,
        batch_size=batch_size, shuffle=False, last_batch='rollover', num_workers=num_workers)

    #when yolo3 model, use this dataloader
    #val_loader = gluon.data.DataLoader(
        #val_dataset.transform(YOLO3DefaultValTransform(width, height)), batchify_fn=batchify_fn,
        #batch_size=batch_size, shuffle=False, last_batch='rollover', num_workers=num_workers)

    return val_loader

#test on validation dataset
def validate(net, val_data, ctx, classes, size, metric):
    net.collect_params().reset_ctx(ctx)
    metric.reset()
    with tqdm(total=size) as pbar:
        start = time.time()
        for ib, batch in enumerate(val_data): #return two values, data and labels
            data = gluon.utils.split_and_load(batch[0], ctx_list=ctx, batch_axis=0, even_split=False)
            label = gluon.utils.split_and_load(batch[1], ctx_list=ctx, batch_axis=0, even_split=False)
            det_bboxes = []
            det_ids = []
            det_scores = []
            gt_bboxes = []
            gt_ids = []
            gt_difficults = []
            for x, y in zip(data, label):
                ids, scores, bboxes = net(x)
                det_ids.append(ids)
                det_scores.append(scores)
                # clip to image size
                det_bboxes.append(bboxes.clip(0, batch[0].shape[2]))
                # split ground truths
                gt_ids.append(y.slice_axis(axis=-1, begin=4, end=5))
                gt_bboxes.append(y.slice_axis(axis=-1, begin=0, end=4))
                gt_difficults.append(y.slice_axis(axis=-1, begin=5, end=6) if y.shape[-1] > 5 else None)

            metric.update(det_bboxes, det_ids, det_scores, gt_bboxes, gt_ids, gt_difficults)
            pbar.update(batch[0].shape[0])
        end = time.time()
        speed = size / (end - start)
        print('Throughput is %f img/sec.'% speed)
    return metric.get()

if __name__ == '__main__':

    batch_size = 8
    #num_iterations = 1
    data_shape = 300
    num_workers = 4
    ctx = mx.gpu()
    model_name = 'yolo'
    net = model_zoo.get_model('ssd_300_vgg16_atrous_voc', pretrained=True, ctx=mx.gpu())
    #int8 model
    #ssd_int8 = model_zoo.get_model('ssd_512_resnet50_v1_voc_int8*', pretrained=True, ctx=mx.gpu())
    #faster = model_zoo.get_model('faster_rcnn_resnet50_v1b_voc', pretrained=True,ctx=mx.gpu())
    #yolo = model_zoo.get_model('yolo3_darknet53_voc', pretrained=True, ctx=mx.gpu())
    #net = yolo


    #a = input("choose models-- 1:ssd-- 2:faster-- 3:yolo")
    #if a == 1:
        #net = ssd
        #model_name = 'ssd'
    #elif a == 2:
        #net = faster
        #model_name = 'faster'
    #else :
        #net = yolo
        #model_name = 'yolo'

    #net.set_nms(nms_thresh=0.45, nms_topk=200)
    #net.hybridize()
    # eval contexts, train on gpu
    num_gpus = 1
    ctx = [mx.gpu(i) for i in range(num_gpus)] if num_gpus > 0 else [mx.cpu()]
    #show the state of jetson nano before benchmarking
    show_navida() # show the situation

    # get dataset
    val_dataset = gdata.VOCDetection(splits=[(2007, 'test')])
    val_metric = VOC07MApMetric(iou_thresh=0.5, class_names=val_dataset.classes)
    #dataloder
    val_data = get_dataloader(val_dataset, data_shape, batch_size, num_workers)
    classes = val_dataset.classes  # class names

    # test on validation dataset
    names, values = validate(net, val_data, ctx, classes, len(val_dataset), val_metric)
    for k, v in zip(names, values):
        print(k, v)
    #check gpu utility on jtp or navida-smi
    show_navida()
