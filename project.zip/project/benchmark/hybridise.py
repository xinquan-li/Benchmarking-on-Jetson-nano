from gluoncv import model_zoo, data, utils
from matplotlib import pyplot as plt
import mxnet as mx
import os
import time

#os.environ["MXNET_CUDNN_AUTOTUNE_DEFAULT"] = "0"
ctx = mx.cpu()#cpu and gpu
#ssd = model_zoo.get_model('ssd_512_resnet50_v1_voc', pretrained=True, ctx=ctx)
faster = model_zoo.get_model('faster_rcnn_resnet50_v1b_voc', pretrained=True, ctx=ctx)
#yolo = model_zoo.get_model('yolo3_darknet53_voc', pretrained=True, ctx=ctx)

#benchmark the infernce time
def benchmark(net):
    path = "./test_data/"
    files = os.listdir(path)
    print(len(files))
    start = time.time()
    for f in files:
        im_fname = utils.download('', path= path + f)
        #x, img = data.transforms.presets.ssd.load_test(im_fname, short=512)
        x, img = data.transforms.presets.rcnn.load_test(im_fname, short=512)
        #x, img = data.transforms.presets.yolo.load_test(im_fname, short=512)
        x = x.as_in_context(ctx)
        class_IDs, scores, bounding_boxs = net(x)
    end = time.time()
    print("finished")
    print("total time is :", (end - start))
#before hybridision
benchmark(faster)

#after hybridisation
faster.hybridize()
benchmark(faster)