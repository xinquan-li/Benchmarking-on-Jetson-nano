import os
import logging
logging.basicConfig(level=logging.INFO)
import time
from gluoncv import model_zoo, data, utils
import numpy as np
import mxnet as mx
from tqdm import tqdm
from mxnet import nd
from mxnet import gluon
import gluoncv as gcv
from gluoncv import data as gdata
from gluoncv.data import batchify
from gluoncv.data.transforms.presets.rcnn import FasterRCNNDefaultValTransform
from gluoncv.utils.metrics.voc_detection import VOC07MApMetric
from gluoncv.utils.metrics.coco_detection import COCODetectionMetric
from jtop import jtop
# disable autotune
os.environ['MXNET_CUDNN_AUTOTUNE_DEFAULT'] = '0'

val_dataset = gdata.VOCDetection(splits=[(2007, 'test')])
val_metric = VOC07MApMetric(iou_thresh=0.5, class_names=val_dataset.classes)

def show_navida():
    print("Navida situation")
    with jtop() as jetson:
            # Read tegra stats
            print(jetson.stats)
            # Status disk
            print(jetson.disk)

def get_dataloader(net, val_dataset, batch_size, num_workers):
    val_bfn = batchify.Tuple(*[batchify.Append() for _ in range(3)])
    val_loader = mx.gluon.data.DataLoader(

        val_dataset.transform(FasterRCNNDefaultValTransform(net.short, net.max_size)),

        batch_size, False, batchify_fn=val_bfn, last_batch='keep', num_workers=num_workers)

    return val_loader

def split_and_load(batch, ctx_list):

    """Split data to 1 batch each device."""
    num_ctx = len(ctx_list)
    new_batch = []
    for i, data in enumerate(batch):
        new_data = [x.as_in_context(ctx) for x, ctx in zip(data, ctx_list)]
        new_batch.append(new_data)
    return new_batch

def validate(net, val_data, ctx, eval_metric, size):

    """Test on validation dataset."""
    clipper = gcv.nn.bbox.BBoxClipToImage()
    eval_metric.reset()
    net.hybridize(static_alloc=True)
    with tqdm(total=size) as pbar:
        start = time.time()
        for ib, batch in enumerate(val_data):
            batch = split_and_load(batch, ctx_list=ctx)
            det_bboxes = []
            det_ids = []
            det_scores = []
            gt_bboxes = []
            gt_ids = []
            gt_difficults = []
            for x, y, im_scale in zip(*batch):
                #prediction on VOC validation dataset
                ids, scores, bboxes = net(x)
                det_ids.append(ids)
                det_scores.append(scores)
                # clip to image size
                det_bboxes.append(clipper(bboxes, x))
                # rescale to original resolution
                im_scale = im_scale.reshape((-1)).asscalar()
                det_bboxes[-1] *= im_scale

                # split ground truths
                gt_ids.append(y.slice_axis(axis=-1, begin=4, end=5))
                gt_bboxes.append(y.slice_axis(axis=-1, begin=0, end=4))
                gt_bboxes[-1] *= im_scale
                gt_difficults.append(y.slice_axis(axis=-1, begin=5, end=6) if y.shape[-1] > 5 else None)

            # update metric
            for det_bbox, det_id, det_score, gt_bbox, gt_id, gt_diff in zip(det_bboxes, det_ids, det_scores, gt_bboxes, gt_ids, gt_difficults):
                eval_metric.update(det_bbox, det_id, det_score, gt_bbox, gt_id, gt_diff)
            pbar.update(len(ctx))
        end = time.time()
        speed = size / (end - start) #calculate the speed on validation dataset
        print('Throughput is %f img/sec.' % speed)
    return eval_metric.get()

if __name__ == '__main__':
    ctx = [mx.gpu(0)]
    ctx = ctx if ctx else [mx.cpu()]
    batch_size = len(ctx)
    num_workers = 4
    net = model_zoo.get_model('faster_rcnn_resnet50_v1b_voc', pretrained=True)
    net.collect_params().reset_ctx(ctx)
    #check the situation of Jetson nano
    show_navida()
    val_dataset = gdata.VOCDetection(splits=[(2007, 'test')])
    val_metric = VOC07MApMetric(iou_thresh=0.5, class_names=val_dataset.classes)
    val_data = get_dataloader(net, val_dataset, batch_size, num_workers)

    #run on validation dataset
    names, values = validate(net, val_data, ctx, val_metric, len(val_dataset))
    for k, v in zip(names, values):
        print(k, v)
        # check gpu utility on jtp or navida-smi
        show_navida()
