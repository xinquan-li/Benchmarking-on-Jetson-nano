from gluoncv import model_zoo, data, utils
from matplotlib import pyplot as plt
import time
import mxnet as mx
import os

os.environ["MXNET_CUDNN_AUTOTUNE_DEFAULT"] = "0"
ctx = mx.gpu()
ssd = model_zoo.get_model('ssd_512_resnet50_v1_voc', pretrained=True, ctx=mx.gpu())
faster_rcnn = model_zoo.get_model('faster_rcnn_resnet50_v1b_voc', pretrained=True, ctx=ctx)
yolo_v3 = model_zoo.get_model('yolo3_darknet53_voc', pretrained=True, ctx=ctx)
# choose the model, and equal to net
net = faster_rcnn

path = "./test_data/"
files = os.listdir(path)
print(len(files))
start = time.time()
#read all raw images in files, and run infernce task
for f in files:
    im_fname = utils.download('', path= path + f)
    x, img = data.transforms.presets.rcnn.load_test(im_fname, short=512)
    x = x.as_in_context(ctx)
    class_IDs, scores, bounding_boxs = net(x)#read data
    class_IDs.asnumpy()#ids
    #scores
    scores.asnumpy()
    #bounding box
    bounding_boxs.asnumpy()

#calculate time
end = time.time()
print("finished")
print("total time is :", (end - start))
speed = len(files) / (end - start)
print('Inference speed is %.2f img/sec' % speed)